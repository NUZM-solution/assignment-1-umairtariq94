using System;
using System.Data;
using System.Windows.Forms;

public partial class UmairTariqForm : Form // Updated class name to reflect your name
{
    DataTable dt = new DataTable();

    public UmairTariqForm() // Updated constructor name
    {
        InitializeComponent(); // This initializes all UI components
        CreateNewRow(); // Initialize columns when the form loads
    }

    public void CreateNewRow()
    {
        if (dt.Columns.Count == 0) // Create columns only once
        {
            dt.Columns.Add(new DataColumn("Course Code", typeof(string))); // Column name for course code
            dt.Columns.Add(new DataColumn("Course Title", typeof(string))); // Column name for course title
            dt.Columns.Add(new DataColumn("Obtained Marks", typeof(int))); // Column name for obtained marks
            dt.Columns.Add(new DataColumn("Grade", typeof(string))); // Column name for grade
            dt.Columns.Add(new DataColumn("Status", typeof(string))); // Column name for status
        }
    }

    public void AddRowToDataTable()
    {
        // Add a new row with user inputs
        dt.Rows.Add(
            txt_courseCode.Text, // TextBox for course code
            txt_courseTitle.Text, // TextBox for course title
            Convert.ToInt32(txt_obtainedMarks.Text), // TextBox for obtained marks
            txt_grade.Text, // TextBox for grade
            txt_status.Text // TextBox for status
        );
        dataGridView1.DataSource = dt; // Update DataGridView with the new data
    }

    private void btn_add_Click(object sender, EventArgs e) // Changed button name for clarity
    {
        AddRowToDataTable(); // Call the method to add a new row when the button is clicked
    }
}
