namespace Umair_s_Table // Updated namespace to reflect the new context
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new UmairTariqForm()); // Updated to reference the correct form
        }
    }
}
